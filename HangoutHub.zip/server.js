import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import mongoose from 'mongoose';
import Room from './Room.js';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Serve index.html for all routes (SPA)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Connect to MongoDB
const MONGODB_URL = process.env.MONGODB_URL || 'mongodb://localhost:27017/hangouthub';
mongoose.connect(MONGODB_URL)
  .then(() => console.log('✅ MongoDB Connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Helper to fetch participants
async function getParticipantsData(roomCode) {
  const sockets = await io.in(roomCode).fetchSockets();
  return sockets.map(s => ({
    id: s.id,
    name: s.userProfile?.name ?? 'Guest'
  }));
}

// Socket.IO connection handling
io.on('connection', socket => {
  console.log(`User connected: ${socket.id}`);

  socket.on('create-room', async ({ hostProfile }) => {
    try {
      const room = new Room({
        hostName: hostProfile.name,
        hostProfile,
        admissionRequired: true,
        waitingList: []
      });
      await room.save();

      socket.userProfile = hostProfile;
      socket.join(room.code);

      io.to(socket.id).emit('room-created', {
        roomCode: room.code,
        room,
        hostUser: { id: socket.id, ...hostProfile }
      });

      console.log(`Room ${room.code} created by ${hostProfile.name}`);
    } catch (err) {
      console.error('Error creating room:', err);
      socket.emit('error', { message: 'Failed to create room' });
    }
  });

  socket.on('join-room', async ({ roomCode, userName }) => {
    try {
      const room = await Room.findOne({ code: roomCode });
      if (!room) {
        socket.emit('error', { message: 'Room not found' });
        return;
      }

      const userProfile = { name: userName };
      socket.userProfile = userProfile;

      if (room.admissionRequired && room.hostName !== userName) {
        room.waitingList.push({ 
          id: socket.id, 
          name: userName, 
          profile: userProfile 
        });
        await room.save();

        // Notify host of admission request
        const sockets = await io.in(room.code).fetchSockets();
        sockets.forEach(s => {
          if (s.userProfile?.name === room.hostName) {
            io.to(s.id).emit('admission-request', {
              roomCode,
              user: { id: socket.id, name: userName }
            });
          }
        });

        io.to(socket.id).emit('waiting-for-admission', {
          room,
          user: { id: socket.id, name: userName },
          message: 'Waiting for host to admit you'
        });
        return;
      }

      socket.join(room.code);
      const participants = await getParticipantsData(room.code);

      io.to(socket.id).emit('room-joined', {
        room,
        user: { id: socket.id, name: userName },
        participants: participants.filter(p => p.id !== socket.id)
      });

      socket.to(room.code).emit('user-joined', { 
        id: socket.id, 
        name: userName 
      });

    } catch (err) {
      console.error('Error joining room:', err);
      socket.emit('error', { message: 'Failed to join room' });
    }
  });

  socket.on('admit-user', async ({ roomCode, userId, admit }) => {
    try {
      const room = await Room.findOne({ code: roomCode });
      if (!room) return;

      room.waitingList = room.waitingList.filter(u => u.id !== userId);
      await room.save();

      if (admit) {
        const admittedSocket = io.sockets.sockets.get(userId);
        if (admittedSocket) {
          admittedSocket.join(roomCode);
          const participants = await getParticipantsData(roomCode);
          
          io.to(userId).emit('room-joined', {
            room,
            user: { id: userId, name: admittedSocket.userProfile?.name },
            participants: participants.filter(p => p.id !== userId)
          });
          
          io.in(roomCode).emit('user-joined', {
            id: userId,
            name: admittedSocket.userProfile?.name
          });
        }
      } else {
        io.to(userId).emit('admission-rejected', {
          roomCode,
          message: 'Host rejected your join request'
        });
      }
    } catch (err) {
      console.error('Error admitting user:', err);
    }
  });

  // Chat messages
  socket.on('send-message', async ({ roomCode, message }) => {
    try {
      const room = await Room.findOne({ code: roomCode });
      if (!room) return;

      const messageData = {
        sender: socket.userProfile?.name || 'Unknown',
        message,
        timestamp: new Date()
      };

      room.messages.push(messageData);
      await room.save();

      io.in(roomCode).emit('new-message', messageData);
    } catch (err) {
      console.error('Error sending message:', err);
    }
  });

  // WebRTC signaling
  socket.on('signal', ({ to, description, candidate }) => {
    socket.to(to).emit('signal', {
      from: socket.id,
      description,
      candidate
    });
  });

  // Media status updates
  socket.on('media-status-update', ({ roomCode, userId, isAudioMuted, isVideoMuted, isScreenSharing }) => {
    socket.to(roomCode).emit('media-status-update', { 
      userId, 
      isAudioMuted, 
      isVideoMuted, 
      isScreenSharing 
    });
  });

  socket.on('speaking-status', ({ roomCode, isSpeaking }) => {
    socket.to(roomCode).emit('speaking-status', { 
      userId: socket.id, 
      isSpeaking 
    });
  });

  // Disconnect handling
  socket.on('disconnect', async () => {
    console.log(`User disconnected: ${socket.id}`);
    
    const rooms = Array.from(socket.rooms);
    for (const roomCode of rooms) {
      if (roomCode !== socket.id) {
        try {
          const room = await Room.findOne({ code: roomCode });
          if (room) {
            room.waitingList = room.waitingList.filter(u => u.id !== socket.id);
            await room.save();
          }
          
          socket.to(roomCode).emit('user-left', { userId: socket.id });
        } catch (err) {
          console.error('Error handling disconnect:', err);
        }
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 HangoutHub server running on http://localhost:${PORT}`);
});