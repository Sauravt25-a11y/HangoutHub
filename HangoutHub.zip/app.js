const socket = io();

let userProfile = null;
let currentUser = null;
let currentRoom = null;
let localStream = null;
let localScreenStream = null;
const peerConnections = {};

// Generate unique ID
function generateUniqueId() {
  return 'user_' + Math.random().toString(36).substr(2, 9);
}

// DOM Elements
const homePage = document.getElementById('homePage');
const chatApp = document.getElementById('chatApp');
const usernameInput = document.getElementById('username');
const loginBtn = document.getElementById('loginBtn');
const createRoomBtn = document.getElementById('createRoomBtn');
const joinRoomBtn = document.getElementById('joinRoomBtn');
const roomCodeInput = document.getElementById('roomCodeInput');
const copyRoomCodeBtn = document.getElementById('copyRoomCode');
const roomCodeDisplay = document.getElementById('roomCodeDisplay');
const userList = document.getElementById('userList');
const messageForm = document.getElementById('messageForm');
const messageInput = document.getElementById('messageInput');
const messagesContainer = document.getElementById('messages');
const chatPanel = document.getElementById('chatPanel');
const localVideo = document.getElementById('localVideo');
const remoteVideos = document.getElementById('remoteVideos');

// Login functionality
loginBtn.addEventListener('click', () => {
  const username = usernameInput.value.trim();
  if (!username) {
    alert('Please enter your name');
    return;
  }
  
  if (username.length > 20) {
    alert('Name must be 20 characters or less');
    return;
  }

  userProfile = { name: username };
  console.log('User logged in:', userProfile);

  // Enable room controls
  createRoomBtn.disabled = false;
  roomCodeInput.disabled = false;
  joinRoomBtn.disabled = false;

  alert(`Welcome, ${username}! You can now create or join a room.`);
});

// Room creation
createRoomBtn.addEventListener('click', () => {
  if (!userProfile) {
    alert('Please enter your name first');
    return;
  }
  socket.emit('create-room', { hostProfile: userProfile });
});

// Room joining
joinRoomBtn.addEventListener('click', () => {
  if (!userProfile) {
    alert('Please enter your name first');
    return;
  }
  
  const roomCode = roomCodeInput.value.trim().toUpperCase();
  if (!roomCode) {
    alert('Please enter a room code');
    return;
  }
  
  socket.emit('join-room', { roomCode, userName: userProfile.name });
});

// Copy room code
copyRoomCodeBtn.addEventListener('click', async () => {
  const code = roomCodeDisplay.textContent;
  try {
    await navigator.clipboard.writeText(code);
    copyRoomCodeBtn.textContent = 'Copied!';
    setTimeout(() => {
      copyRoomCodeBtn.textContent = 'Copy Code';
    }, 2000);
  } catch (err) {
    console.error('Failed to copy:', err);
  }
});

// Chat functionality
document.getElementById('chatToggleBtn').addEventListener('click', () => {
  chatPanel.classList.toggle('translate-x-full');
});

document.getElementById('closeChatBtn').addEventListener('click', () => {
  chatPanel.classList.add('translate-x-full');
});

messageForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const message = messageInput.value.trim();
  if (!message || !currentRoom) return;
  
  socket.emit('send-message', { 
    roomCode: currentRoom.code, 
    message 
  });
  messageInput.value = '';
});

// Leave call
document.getElementById('leaveCallBtn').addEventListener('click', () => {
  if (confirm('Are you sure you want to leave the call?')) {
    leaveCall();
  }
});

// Socket event handlers
socket.on('room-created', async ({ roomCode, room, hostUser }) => {
  currentRoom = room;
  currentUser = hostUser;
  if (!currentUser.id) currentUser.id = generateUniqueId();

  showChatApp();
  roomCodeDisplay.textContent = roomCode;
  
  await startLocalMedia();
  renderParticipants([currentUser]);
  renderMessages(room.messages || []);
  
  document.getElementById('admitAllBtn').classList.remove('hidden');
});

socket.on('room-joined', async ({ room, user, participants }) => {
  currentRoom = room;
  currentUser = user;
  if (!currentUser.id) currentUser.id = generateUniqueId();

  showChatApp();
  roomCodeDisplay.textContent = room.code;
  
  renderParticipants([currentUser, ...participants]);
  renderMessages(room.messages || []);
  
  await startLocalMedia();
  participants.forEach(p => startConnection(p.id));
});

socket.on('waiting-for-admission', ({ message }) => {
  alert(message);
});

socket.on('admission-rejected', ({ message }) => {
  alert(message);
  showHomePage();
});

socket.on('user-joined', ({ id, name }) => {
  console.log(`${name} joined the room`);
  addMessage({
    sender: 'System',
    message: `${name} joined the room`,
    type: 'system'
  });
  startConnection(id);
});

socket.on('user-left', ({ userId }) => {
  console.log(`User ${userId} left`);
  
  // Remove peer connection
  if (peerConnections[userId]) {
    peerConnections[userId].close();
    delete peerConnections[userId];
  }
  
  // Remove video element
  const videoElement = document.getElementById(userId);
  if (videoElement) {
    videoElement.remove();
  }
});

socket.on('new-message', (messageData) => {
  addMessage(messageData);
});

socket.on('error', ({ message }) => {
  alert(message);
});

// WebRTC signaling
socket.on('signal', async ({ from, description, candidate }) => {
  if (!peerConnections[from]) {
    await startConnection(from, false);
  }
  
  const pc = peerConnections[from];
  
  if (description) {
    await pc.setRemoteDescription(description);
    if (description.type === 'offer') {
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      socket.emit('signal', { 
        to: from, 
        description: pc.localDescription 
      });
    }
  }
  
  if (candidate) {
    await pc.addIceCandidate(candidate);
  }
});

// Helper functions
function showChatApp() {
  homePage.classList.add('hidden');
  chatApp.classList.remove('hidden');
}

function showHomePage() {
  chatApp.classList.add('hidden');
  homePage.classList.remove('hidden');
}

async function startLocalMedia() {
  try {
    if (!localStream) {
      localStream = await navigator.mediaDevices.getUserMedia({ 
        video: true, 
        audio: true 
      });
    }
    localVideo.srcObject = localStream;
    initializeMediaControls();
  } catch (err) {
    console.error('Error accessing media:', err);
    alert('Could not access camera/microphone. Please check permissions.');
  }
}

async function startConnection(peerId, isInitiator = true) {
  const pc = new RTCPeerConnection({
    iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
  });
  
  peerConnections[peerId] = pc;
  
  // Add local tracks
  localStream.getTracks().forEach(track => {
    pc.addTrack(track, localStream);
  });
  
  // Create remote video element
  const remoteVideo = document.createElement('video');
  remoteVideo.id = peerId;
  remoteVideo.autoplay = true;
  remoteVideo.playsInline = true;
  remoteVideo.className = 'w-full h-full rounded-lg bg-black object-cover';
  
  const videoContainer = document.createElement('div');
  videoContainer.className = 'relative bg-gray-700 rounded-lg overflow-hidden min-h-[200px]';
  videoContainer.appendChild(remoteVideo);
  
  remoteVideos.appendChild(videoContainer);
  
  pc.ontrack = (event) => {
    remoteVideo.srcObject = event.streams[0];
  };
  
  pc.onicecandidate = (event) => {
    if (event.candidate) {
      socket.emit('signal', {
        to: peerId,
        candidate: event.candidate
      });
    }
  };
  
  if (isInitiator) {
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    socket.emit('signal', {
      to: peerId,
      description: pc.localDescription
    });
  }
}

function renderParticipants(participants) {
  userList.innerHTML = '';
  participants.forEach(participant => {
    const li = document.createElement('li');
    li.className = 'p-2 bg-gray-800 rounded text-sm';
    li.textContent = participant.name;
    userList.appendChild(li);
  });
}

function renderMessages(messages) {
  messagesContainer.innerHTML = '';
  messages.forEach(message => addMessage(message));
}

function addMessage({ sender, message, type = 'user' }) {
  const messageDiv = document.createElement('div');
  messageDiv.className = 'p-2 rounded';
  
  if (type === 'system') {
    messageDiv.className += ' text-gray-400 italic text-sm';
    messageDiv.textContent = message;
  } else {
    messageDiv.className += ' bg-gray-800';
    messageDiv.innerHTML = `
      <div class="font-semibold text-blue-400 text-sm">${sender}</div>
      <div class="mt-1">${message}</div>
    `;
  }
  
  messagesContainer.appendChild(messageDiv);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Media controls
let isAudioMuted = false;
let isVideoMuted = false;
let isScreenSharing = false;

function initializeMediaControls() {
  document.getElementById('micBtn').addEventListener('click', toggleMicrophone);
  document.getElementById('cameraBtn').addEventListener('click', toggleCamera);
  document.getElementById('screenShareBtn').addEventListener('click', toggleScreenShare);
}

function toggleMicrophone() {
  if (!localStream) return;
  
  const audioTrack = localStream.getAudioTracks()[0];
  if (audioTrack) {
    isAudioMuted = !isAudioMuted;
    audioTrack.enabled = !isAudioMuted;
    
    const micBtn = document.getElementById('micBtn');
    micBtn.classList.toggle('bg-red-500', isAudioMuted);
    micBtn.classList.toggle('bg-green-500', !isAudioMuted);
  }
}

function toggleCamera() {
  if (!localStream) return;
  
  const videoTrack = localStream.getVideoTracks()[0];
  if (videoTrack) {
    isVideoMuted = !isVideoMuted;
    videoTrack.enabled = !isVideoMuted;
    
    const cameraBtn = document.getElementById('cameraBtn');
    cameraBtn.classList.toggle('bg-red-500', isVideoMuted);
    cameraBtn.classList.toggle('bg-blue-500', !isVideoMuted);
    
    localVideo.style.display = isVideoMuted ? 'none' : 'block';
  }
}

async function toggleScreenShare() {
  const screenBtn = document.getElementById('screenShareBtn');
  
  try {
    if (!isScreenSharing) {
      localScreenStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true
      });
      
      const videoTrack = localScreenStream.getVideoTracks()[0];
      
      // Replace video track in all peer connections
      Object.values(peerConnections).forEach(pc => {
        const sender = pc.getSenders().find(s => 
          s.track && s.track.kind === 'video'
        );
        if (sender) {
          sender.replaceTrack(videoTrack);
        }
      });
      
      localVideo.srcObject = localScreenStream;
      isScreenSharing = true;
      screenBtn.classList.add('bg-orange-500');
      
      videoTrack.onended = stopScreenShare;
    } else {
      stopScreenShare();
    }
  } catch (err) {
    console.error('Error sharing screen:', err);
  }
}

function stopScreenShare() {
  if (localScreenStream) {
    localScreenStream.getTracks().forEach(track => track.stop());
  }
  
  // Replace back to camera
  const videoTrack = localStream.getVideoTracks()[0];
  Object.values(peerConnections).forEach(pc => {
    const sender = pc.getSenders().find(s => 
      s.track && s.track.kind === 'video'
    );
    if (sender) {
      sender.replaceTrack(videoTrack);
    }
  });
  
  localVideo.srcObject = localStream;
  isScreenSharing = false;
  
  const screenBtn = document.getElementById('screenShareBtn');
  screenBtn.classList.remove('bg-orange-500');
}

function leaveCall() {
  // Stop all streams
  if (localStream) {
    localStream.getTracks().forEach(track => track.stop());
  }
  if (localScreenStream) {
    localScreenStream.getTracks().forEach(track => track.stop());
  }
  
  // Close all peer connections
  Object.values(peerConnections).forEach(pc => pc.close());
  
  // Clear state
  localStream = null;
  localScreenStream = null;
  currentRoom = null;
  currentUser = null;
  userProfile = null;
  
  // Reset UI
  remoteVideos.innerHTML = '';
  messagesContainer.innerHTML = '';
  userList.innerHTML = '';
  roomCodeInput.value = '';
  usernameInput.value = '';
  
  // Disable buttons
  createRoomBtn.disabled = true;
  joinRoomBtn.disabled = true;
  roomCodeInput.disabled = true;
  
  showHomePage();
}